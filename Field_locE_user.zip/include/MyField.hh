#ifndef CPROJECT_MyFIELD_HH
#define CPROJECT_MyFIELD_HH

#include "CylinderField.hh"

#include "G4SystemOfUnits.hh"
#include "G4UniformElectricField.hh"
#include "G4UniformMagField.hh"
#include "G4MagneticField.hh"
#include "G4ElectricField.hh"
#include "G4FieldManager.hh"
#include "G4TransportationManager.hh"
#include "G4EquationOfMotion.hh"
#include "G4EqMagElectricField.hh"
#include "G4Mag_UsualEqRhs.hh"
#include "G4MagIntegratorStepper.hh"
#include "G4MagIntegratorDriver.hh"
#include "G4ChordFinder.hh"

#include "G4ClassicalRK4.hh"

class MyField
{
 public:

  CylinderField* myEMfield;
  G4EqMagElectricField* myEquation;
  G4MagIntegratorStepper* myStepper;
  G4MagInt_Driver* myntgrDriver;
  G4ChordFinder* myChordFinder; 
  G4FieldManager* myFieldManager;

  MyField();
  ~MyField();
};
 
#endif //CPROJECT_MyFIELD_HH