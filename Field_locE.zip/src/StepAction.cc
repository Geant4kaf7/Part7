  #include <StepAction.hh>
#include <EventAct.hh>//подключаем библиотеку с используемым счетчиком


// Обработчик событий на уровне Step - просчет отдельного шага/акта взаимодействия

void StepAct::UserSteppingAction(const G4Step* step) 
{
 G4StepPoint* point1 = step->GetPreStepPoint();  
 G4StepPoint* point2 = step->GetPostStepPoint();
 G4ThreeVector vect1, vect2;
// G4double Ekin1, Ekin2;

 vect1=point1->GetPosition();
 vect2=point2->GetPosition();  
 G4double edep = 0.;
 edep          = step->GetTotalEnergyDeposit();
 EventAct::AddE(edep);

 if (strcmp("G4_Si",step->GetPreStepPoint()->GetMaterial()->GetName())==0)
 {
  G4TouchableHandle touchable=step->GetPreStepPoint()->GetTouchableHandle();
  G4int copyNo=touchable->GetVolume(0)->GetCopyNo(); 
  (*f_step)<<copyNo<<" "<<edep<<G4endl;
 }
}
