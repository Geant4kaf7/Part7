#include "Si_det_Parameterisation.hh"

using namespace std;


Si_det_Parameterisation::Si_det_Parameterisation() {}

Si_det_Parameterisation::~Si_det_Parameterisation() {}

void Si_det_Parameterisation::ComputeTransformation (const G4int copyNo, G4VPhysicalVolume* physVol) const
{
 G4double Xposition= 0.* cm;
 G4double Yposition= 0.* cm;
 G4double Zposition= 0.* cm;

 Xposition = -9.*cm + (2.*cm)*copyNo;
 
 G4ThreeVector origin(Xposition,Yposition,Zposition);
 physVol->SetTranslation(origin);
 physVol->SetRotation(0);
}

void Si_det_Parameterisation::ComputeDimensions (G4Box& Si_det_box, const G4int, const G4VPhysicalVolume*) const
{
 G4double XhalfLength = 1.* cm;
 G4double YhalfLength = 1 * cm;
 G4double ZhalfLength = 1.* cm; 
 Si_det_box.SetXHalfLength(XhalfLength);
 Si_det_box.SetYHalfLength(YhalfLength);
 Si_det_box.SetZHalfLength(ZhalfLength);
}

/*G4Material* ComputeMaterial (const G4int copyNo, G4VPhysicalVolume* physVol, const G4VTouchable *parentTouch=0)
{
 G4Material* mat;
 G4NistManager* nist;
 nist = G4NistManager::Instance();
 G4VisAttributes* CWhite  = new G4VisAttributes(G4Colour(1, 1, 1, 0.3));
 G4TouchableHandle hand=parentTouch->GetTouchableHandle();
 if (copyNo==1)
 {
  mat=nist->FindOrBuildMaterial("G4_Si");
  physVol->GetLogicalVolume()->SetVisAttributes(CWhite);
 }
 else
 {
  mat=nist->FindOrBuildMaterial("G4_Si");
 }
 return mat;
}*/
